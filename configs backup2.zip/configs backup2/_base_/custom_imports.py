custom_imports = dict(
    imports=[
        'medfmc.models', 'medfmc.datasets.medical_datasets',
        'medfmc.core.evaluation'
    ],
    allow_failed_imports=False)
